package com.rafael.healthtracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthTrackerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
