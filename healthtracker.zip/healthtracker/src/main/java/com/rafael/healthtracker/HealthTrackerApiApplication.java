package com.rafael.healthtracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthTrackerApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthTrackerApiApplication.class, args);
	}

}
